//Swap 2 numbers (a and b ) without a 3rd temp varialbe

//not allowed
//let temp =a
//a=b
//b=temp
//NOT ALLOWED TO USE JS FUNCIOTNS/FUNCITONALITIES TO DO THIS AS WELL 
let a=5
let b=10
console.log(a,b)
a= a+b; //15
b= a-b // 5
a= a-b // 10 
 console.log(a,b) 