
// let c = 10
// const outerFunction = (a)=>{
//     let b = 10;
//     const innerFunction = ()=>{
//         let sum = a+b+c
//         console.log(`sum of numbers is ${sum}`)
//     }
//     return innerFunction;
// }
// let inner = outerFunction(7)
// console.log(inner)
// inner();


console.log(this)