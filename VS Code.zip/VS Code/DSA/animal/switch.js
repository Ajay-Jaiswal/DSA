// let sum="triangle";

// switch(sum){
//   case "rectangle":
//     console.log("mahir")
//     break;
//   case "triangle":
//     console.log("jafar")
//     break;
// }


// let num =0
// while(num<=10){
//     console.log(num)
//     num++
// }

//do while
// let num =11
// do{
//     console.log(num)
//     num++
// }while(num<=10)

// for each
// let arr=[5,7,8,9]
// arr.forEach((ele,ind,arr)=>{
// console.log(ele,ind,arr)
// })

// function sum(){
//     console.log("mahir")
// }
//arrow function
// total()
// let total=()=>{
//     console.log("mahir")
// }

//Anonymous function
// var sum=function(a,b){
//     return c=a+b
// }
//   let total=sum(5,5)
//   console.log(total)


//diff between let var and const
//{
    //let a=5
  //  var b=5
    //const c=5
//}
//console.log(a)
//console.log(b)
//console.log(c)

//function sum(){
    //let a=5
    //var b=5
    //const c=5
//}
//console.log(a)
//console.log(b)
//console.log(c)
//sum()


// function sum(){
//     let a=5
//     {
//     let c=5    //var and const are block scope
//     }
//     const c=5
//     console.log(b)
// }
// sum()