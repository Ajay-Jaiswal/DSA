//there is an array of animals . the animal cabn be erpeated .Give me the data that how many time echa animal is repeated;
//  let animals = ["goat", "dog", "cat","dog","cat"]
//  function animalCount(animals){
//      let animalFreq ={}
//      for(let animal of animals){
//          if(animalFreq[animal]){
//              animalFreq[animal]+=1
//          }else{
//              animalFreq[animal] =1
//          }
//      }
//      console.log(animalFreq)
//  }
//  animalCount(animals)

