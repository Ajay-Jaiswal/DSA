let stack={}

console.log(stack)
stack.Push(2)
stack.Push(3)
console.log(stack)
