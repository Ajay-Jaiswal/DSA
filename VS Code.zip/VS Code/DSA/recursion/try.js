// function sum(...a){
//   return a.reduce((acc,curr)=>{
//     return acc+curr  
//   },100)
// }
// console.log(sum(1,2,3,4))


// const array = [1, 2, 3, 4, 5];
   
// let b=array.find((ele)=>{
//   return ele>2
// })
//   console.log(b)


// const array = [1, 2, 3, 4, 5];
   
// let b=array.filter((ele)=>{
//   return ele>2
// })
//   console.log(b)

//  const array = [1, 2, 3, 4, 5];
   
// let b=array.indexOf(5)
//   console.log(b)

   
// let b=array.map((ele)=>{
//   return ele>2
// })
//   console.log(b)


// let array=[8,6,7,4,8,3]

// let c=array.map((ele)=>{
//     return ele*2
// }).filter((ele)=>{
//    return ele<10
// }).reduce((acc,curr)=>{
//   return acc+=curr
// })
// console.log(c)


// let array=[8,6,7,4,8,2]

// let c=array.map((ele)=>ele*2).filter((ele)=> ele<10).reduce((acc,curr)=>acc+=curr)
// console.log(c)

// let str="mahir ,jafajr"
// let c= str.indexOf("j",8)
// console.log(c)



// let str="mahir ,jafajrj"
// let c= str.lastIndexOf("r")
// console.log(c)

//doubt
// let str="mahir jafajr"
// let c= str.lastIndexOf("j",3)
// console.log(c)

//escape char
// let str="mahir jafajr "mahir" jafar"; //not work
// console.log(str)
// let str="mahir jafajr 'mahir' jafar"; //work
// console.log(str)
// let str="mahir jafajr \"mahir\" jafar";  //work
// console.log(str)


// let arr=[[5,6],[7,5],[2,8]]

// let c=arr.reduce((acc,curr)=> acc.concat(curr))
// console.log(c)

//doubt
// let str="mahir jafajr"
// let c= str.search("j",8)
// console.log(c)

// let str="mahir jafajr"
// let c= str.charAt(4)
// console.log(c)

// let str="mahir jafajr"
// let c= str.charCodeAt(7)
// console.log(c)

