var i = 40;
function junaid(){
    // var i =30;
    function amir(){
        i++;
        console.log(i);
        var i =20;
    }amir()
}
junaid()

